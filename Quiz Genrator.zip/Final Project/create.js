let quizzes = [];

document.getElementById('add-question').addEventListener('click', function() {
    const question = document.getElementById('question').value;
    const options = [
        document.getElementById('option1').value,
        document.getElementById('option2').value,
        document.getElementById('option3').value,
        document.getElementById('option4').value
    ];
    const correctAnswer = document.getElementById('correct-answer').value;

    if (question && options.every(opt => opt) && correctAnswer) {
        quizzes.push({ question, options, correctAnswer });
        alert('Question added!');
        clearInputs();
    } else {
        alert('Please fill in all fields.');
    }
});

document.getElementById('create-quiz').addEventListener('click', function() {
    const title = document.getElementById('quiz-title').value;
    if (title && quizzes.length > 0) {
        displayQuiz(title);
    } else {
        alert('Please provide a quiz title and add at least one question.');
    }
});

function clearInputs() {
    document.getElementById('question').value = '';
    document.getElementById('option1').value = '';
    document.getElementById('option2').value = '';
    document.getElementById('option3').value = '';
    document.getElementById('option4').value = '';
    document.getElementById('correct-answer').value = '';
}

function displayQuiz(title) {
    document.getElementById('quiz-title-display').innerText = title;
    const questionsContainer = document.getElementById('questions-container');
    questionsContainer.innerHTML = '';
    quizzes.forEach((quiz, index) => {
        const questionHTML = `
            <div>
                <p>${index + 1}. ${quiz.question}</p>
                ${quiz.options.map((opt, i) => `
                    <label>
                        <input type="radio" class="radio" name="question${index}" value="${opt}"> ${opt}
                    </label>
                `).join('')}
            </div>
        `;
        questionsContainer.innerHTML += questionHTML;
    });
    document.getElementById('quiz-creation').style.display = 'none';
    document.getElementById('quiz-taking').style.display = 'block';
}

document.getElementById('submit-quiz').addEventListener('click', function() {
    let score = 0;
    quizzes.forEach((quiz, index) => {
        const selectedOption = document.querySelector(`input[name="question${index}"]:checked`);
        if (selectedOption && selectedOption.value === quiz.correctAnswer) {
            score++;
        }
    });
    displayResults(score);
});

function displayResults(score) {
    const results = document.getElementById('results');
    results.innerHTML = `Your score: ${score} out of ${quizzes.length}`;
    results.style.display = 'block';
    document.getElementById('quiz-taking').style.display = 'none';
}
